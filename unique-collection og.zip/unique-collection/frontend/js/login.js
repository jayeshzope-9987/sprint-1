const tabs = document.querySelectorAll(".auth-tab");
const loginForm = document.getElementById("login-form");
const signupForm = document.getElementById("signup-form");

tabs.forEach((tab) => {
  tab.addEventListener("click", () => {
    tabs.forEach((t) => t.classList.remove("active"));
    tab.classList.add("active");
    const isLogin = tab.dataset.tab === "login";
    loginForm.classList.toggle("hidden", !isLogin);
    signupForm.classList.toggle("hidden", isLogin);
  });
});

loginForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  const username = document.getElementById("login-username").value.trim();
  const password = document.getElementById("login-password").value;
  const msg = document.getElementById("login-msg");
  msg.textContent = "Signing in...";
  msg.className = "auth-msg";

  try {
    const { ok, data } = await apiPost("/login", { username, password });
    if (ok && data.success) {
      localStorage.setItem("uc_username", username);
      window.location.href = "products.html";
    } else {
      msg.textContent = data.message || "Invalid username or password";
      msg.className = "auth-msg error";
    }
  } catch (err) {
    msg.textContent = "Can't reach the backend — is it running on localhost:8080?";
    msg.className = "auth-msg error";
  }
});

signupForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  const username = document.getElementById("signup-username").value.trim();
  const email = document.getElementById("signup-email").value.trim();
  const password = document.getElementById("signup-password").value;
  const msg = document.getElementById("signup-msg");
  msg.textContent = "Creating account...";
  msg.className = "auth-msg";

  try {
    const { ok, data } = await apiPost("/register", { username, email, password });
    msg.textContent = data.message;
    msg.className = "auth-msg " + (ok ? "success" : "error");
    if (ok) {
      setTimeout(() => {
        document.querySelector('[data-tab="login"]').click();
      }, 900);
    }
  } catch (err) {
    msg.textContent = "Can't reach the backend — is it running on localhost:8080?";
    msg.className = "auth-msg error";
  }
});
