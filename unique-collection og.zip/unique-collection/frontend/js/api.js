// Shared helpers used by every page.
// If you run the backend on a different host/port, change API_BASE here.
const API_BASE = "http://localhost:8080/api";

function getClientId() {
  let id = localStorage.getItem("uc_client_id");
  if (!id) {
    id = "client-" + Math.random().toString(36).slice(2) + Date.now();
    localStorage.setItem("uc_client_id", id);
  }
  return id;
}

async function apiGet(path) {
  const res = await fetch(`${API_BASE}${path}`, {
    headers: { "X-Client-Id": getClientId() },
  });
  return res.json();
}

async function apiPost(path, body) {
  const res = await fetch(`${API_BASE}${path}`, {
    method: "POST",
    headers: { "Content-Type": "application/json", "X-Client-Id": getClientId() },
    body: JSON.stringify(body),
  });
  return { ok: res.ok, data: await res.json() };
}

async function apiDelete(path) {
  const res = await fetch(`${API_BASE}${path}`, {
    method: "DELETE",
    headers: { "X-Client-Id": getClientId() },
  });
  return res.json();
}

function requireLogin() {
  if (!localStorage.getItem("uc_username")) {
    window.location.href = "index.html";
  }
}
