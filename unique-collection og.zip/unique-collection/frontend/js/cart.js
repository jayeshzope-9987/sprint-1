const ICONS = {
  lock: "🔒", light: "💡", helmet: "🪖", pedal: "⚙️",
  bell: "🔔", pump: "🚲", bottle: "🧴", saddle: "💺",
};

function formatPrice(n) {
  return "₹" + Number(n).toLocaleString("en-IN");
}

async function loadCart() {
  const list = document.getElementById("cart-items");
  const cart = await apiGet("/cart");
  const items = cart.items || [];

  if (items.length === 0) {
    list.innerHTML = `<p class="cart-empty">Your cart is empty. <a href="products.html">Go shopping →</a></p>`;
  } else {
    list.innerHTML = "";
    items.forEach((item) => {
      const row = document.createElement("div");
      row.className = "cart-row";
      row.innerHTML = `
        <div class="product-icon">${ICONS[item.icon] || "🔧"}</div>
        <div class="cart-row-info">
          <div class="name">${item.name}</div>
          <div class="meta">${formatPrice(item.price)} × ${item.quantity}</div>
        </div>
        <div class="cart-row-price">${formatPrice(item.lineTotal)}</div>
        <button class="remove-btn" data-id="${item.productId}">Remove</button>
      `;
      list.appendChild(row);
    });

    list.querySelectorAll(".remove-btn").forEach((btn) => {
      btn.addEventListener("click", async () => {
        await apiDelete(`/cart?productId=${btn.dataset.id}`);
        loadCart();
      });
    });
  }

  document.getElementById("summary-total").textContent = formatPrice(cart.total || 0);
  document.getElementById("summary-grand").textContent = formatPrice(cart.total || 0);
}

document.getElementById("checkout-btn").addEventListener("click", () => {
  document.getElementById("checkout-msg").textContent =
    "This is a demo project — hook this button up to a real payment flow when you're ready.";
});

loadCart();
