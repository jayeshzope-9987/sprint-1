const ICONS = {
  lock: "🔒", light: "💡", helmet: "🪖", pedal: "⚙️",
  bell: "🔔", pump: "🚲", bottle: "🧴", saddle: "💺",
};

function formatPrice(n) {
  return "₹" + Number(n).toLocaleString("en-IN");
}

async function refreshCartCount() {
  try {
    const cart = await apiGet("/cart");
    const count = (cart.items || []).reduce((sum, i) => sum + i.quantity, 0);
    document.getElementById("cart-count").textContent = count;
  } catch (e) { /* backend not reachable yet — ignore */ }
}

async function loadProducts() {
  const grid = document.getElementById("product-grid");
  grid.innerHTML = `<p class="cart-empty">Loading products...</p>`;

  try {
    const products = await apiGet("/products");
    grid.innerHTML = "";

    products.forEach((p) => {
      const card = document.createElement("article");
      card.className = "product-card";
      card.innerHTML = `
        <div class="product-icon">${ICONS[p.icon] || "🔧"}</div>
        <div class="product-category">${p.category}</div>
        <div class="product-name">${p.name}</div>
        <div class="product-price">${formatPrice(p.price)}</div>
        <div class="product-stock">${p.stock} in stock</div>
        <button class="btn btn-primary add-to-cart" data-id="${p.id}">Add to cart</button>
      `;
      grid.appendChild(card);
    });

    grid.querySelectorAll(".add-to-cart").forEach((btn) => {
      btn.addEventListener("click", async () => {
        btn.textContent = "Adding...";
        await apiPost("/cart", { productId: Number(btn.dataset.id), quantity: 1 });
        btn.textContent = "Added ✓";
        refreshCartCount();
        setTimeout(() => (btn.textContent = "Add to cart"), 1200);
      });
    });
  } catch (err) {
    grid.innerHTML = `<p class="cart-empty">Can't reach the backend. Make sure the Java server is running on localhost:8080.</p>`;
  }
}

document.getElementById("logout-btn").addEventListener("click", () => {
  localStorage.removeItem("uc_username");
  window.location.href = "index.html";
});

requireLogin();
const username = localStorage.getItem("uc_username");
if (username) document.getElementById("welcome-user").textContent = `Hi, ${username}`;

loadProducts();
refreshCartCount();
