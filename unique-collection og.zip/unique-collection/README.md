# Unique Collection — Bike Parts & Accessories Shop

A Flipkart-style shopping project for bike parts and accessories: sign in,
browse the catalog, add items to a cart, and check out.

- **Frontend:** HTML, CSS, vanilla JavaScript (`/frontend`)
- **Backend:** Java, plain JDK `HttpServer` — no frameworks or build tools required (`/backend`)

## Project structure

```
unique-collection/
├── frontend/
│   ├── index.html         # sign in / sign up
│   ├── products.html      # product catalog
│   ├── cart.html          # shopping cart
│   ├── css/style.css
│   └── js/
│       ├── api.js         # shared fetch helpers
│       ├── login.js
│       ├── products.js
│       └── cart.js
└── backend/
    ├── src/com/uniquecollection/
    │   ├── Main.java            # starts the HTTP server
    │   ├── model/                # Product, User, CartItem
    │   ├── service/               # in-memory data + business logic
    │   ├── handler/               # HTTP route handlers (REST-style JSON API)
    │   └── util/                   # tiny JSON + HTTP helpers (no external libs)
    └── README.md          # how to compile and run the backend
```

## Running it

**1. Start the backend** (see `backend/README.md` for full steps):

```bash
cd backend
javac -d bin $(find src -name "*.java")
java -cp bin com.uniquecollection.Main
```

The server starts on `http://localhost:8080`.

**2. Open the frontend:**

Open `frontend/index.html` in VS Code and run it with the **Live Server**
extension (right-click the file → "Open with Live Server"). Opening the file
directly also works, but Live Server gives you auto-reload while you edit.

**3. Log in** with the demo account:

```
username: demo
password: demo123
```

...or create a new account from the "Create account" tab.

## API summary

| Method | Endpoint          | Purpose                          |
|--------|-------------------|-----------------------------------|
| GET    | `/api/products`   | List the catalog                  |
| POST   | `/api/login`      | `{ username, password }`          |
| POST   | `/api/register`   | `{ username, email, password }`   |
| GET    | `/api/cart`       | Get the current cart               |
| POST   | `/api/cart`       | `{ productId, quantity }`         |
| DELETE | `/api/cart?productId=1` | Remove a product from the cart |

## Notes

This is a learning/demo project: data lives in memory and resets whenever the
backend restarts, and passwords are stored as plain text — don't reuse this
auth code for anything real. Swapping in a database (e.g. SQLite or
PostgreSQL) and a password hash (e.g. BCrypt) would be the natural next step.
