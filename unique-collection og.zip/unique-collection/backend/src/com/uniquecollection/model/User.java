package com.uniquecollection.model;

public class User {
    private final String username;
    private String password; // demo only — plain text, never do this in a real app
    private final String email;

    public User(String username, String password, String email) {
        this.username = username;
        this.password = password;
        this.email = email;
    }

    public String getUsername() { return username; }
    public String getPassword() { return password; }
    public String getEmail() { return email; }

    public boolean checkPassword(String attempt) {
        return password != null && password.equals(attempt);
    }
}
