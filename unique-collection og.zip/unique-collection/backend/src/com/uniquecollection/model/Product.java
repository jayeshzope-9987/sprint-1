package com.uniquecollection.model;

public class Product {
    private final int id;
    private final String name;
    private final String category;
    private final double price;
    private final String icon;   // emoji/icon placeholder used by the frontend
    private final int stock;

    public Product(int id, String name, String category, double price, String icon, int stock) {
        this.id = id;
        this.name = name;
        this.category = category;
        this.price = price;
        this.icon = icon;
        this.stock = stock;
    }

    public int getId() { return id; }
    public String getName() { return name; }
    public String getCategory() { return category; }
    public double getPrice() { return price; }
    public String getIcon() { return icon; }
    public int getStock() { return stock; }
}
