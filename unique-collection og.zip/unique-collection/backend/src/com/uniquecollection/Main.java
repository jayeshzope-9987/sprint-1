package com.uniquecollection;

import com.sun.net.httpserver.HttpServer;
import com.uniquecollection.handler.CartHandler;
import com.uniquecollection.handler.LoginHandler;
import com.uniquecollection.handler.ProductHandler;
import com.uniquecollection.handler.RegisterHandler;
import com.uniquecollection.service.CartService;
import com.uniquecollection.service.ProductService;
import com.uniquecollection.service.UserService;

import java.net.InetSocketAddress;

/**
 * Unique Collection — backend entry point.
 * Starts a plain-JDK HTTP server (no external dependencies, no Maven/Gradle
 * needed) that the frontend talks to over a small JSON API.
 */
public class Main {

    private static final int PORT = 8080;

    public static void main(String[] args) throws Exception {
        ProductService productService = new ProductService();
        UserService userService = new UserService();
        CartService cartService = new CartService();

        HttpServer server = HttpServer.create(new InetSocketAddress(PORT), 0);

        server.createContext("/api/products", new ProductHandler(productService));
        server.createContext("/api/login", new LoginHandler(userService));
        server.createContext("/api/register", new RegisterHandler(userService));
        server.createContext("/api/cart", new CartHandler(cartService, productService));

        server.setExecutor(null);
        server.start();

        System.out.println("=======================================================");
        System.out.println(" Unique Collection backend running on http://localhost:" + PORT);
        System.out.println(" Demo login -> username: demo   password: demo123");
        System.out.println(" Endpoints:");
        System.out.println("   GET    /api/products");
        System.out.println("   POST   /api/login");
        System.out.println("   POST   /api/register");
        System.out.println("   GET    /api/cart");
        System.out.println("   POST   /api/cart");
        System.out.println("   DELETE /api/cart?productId=1");
        System.out.println("=======================================================");
    }
}
