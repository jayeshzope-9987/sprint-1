package com.uniquecollection.service;

import com.uniquecollection.model.User;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/** In-memory user store. Demo-grade only — data resets every time the server restarts. */
public class UserService {

    private final Map<String, User> users = new ConcurrentHashMap<>();

    public UserService() {
        // one ready-made demo account so you can log in immediately
        users.put("demo", new User("demo", "demo123", "demo@uniquecollection.test"));
    }

    public boolean register(String username, String password, String email) {
        if (username == null || username.isBlank() || users.containsKey(username)) {
            return false;
        }
        users.put(username, new User(username, password, email));
        return true;
    }

    public boolean login(String username, String password) {
        User user = users.get(username);
        return user != null && user.checkPassword(password);
    }

    public boolean exists(String username) {
        return users.containsKey(username);
    }
}
