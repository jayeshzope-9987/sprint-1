package com.uniquecollection.service;

import com.uniquecollection.model.Product;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/** In-memory product catalog for the Unique Collection bike parts shop. */
public class ProductService {

    private final List<Product> products = new ArrayList<>();

    public ProductService() {
        products.add(new Product(1, "Chain Lock Pro",        "Security",  899.0,  "lock",    40));
        products.add(new Product(2, "LED Light Set (F+R)",    "Lighting",  549.0,  "light",   60));
        products.add(new Product(3, "Cycling Helmet Shield",  "Safety",   1299.0,  "helmet",  25));
        products.add(new Product(4, "Alloy Pedal Set",        "Drivetrain",699.0,  "pedal",   35));
        products.add(new Product(5, "Classic Brass Bell",     "Accessory", 149.0,  "bell",    80));
        products.add(new Product(6, "High-Pressure Air Pump", "Tools",     899.0,  "pump",    20));
        products.add(new Product(7, "Insulated Bottle Holder","Accessory", 249.0,  "bottle",  50));
        products.add(new Product(8, "Memory Foam Saddle",     "Comfort",  1099.0,  "saddle",  30));
    }

    public List<Product> getAll() {
        return products;
    }

    public Optional<Product> getById(int id) {
        return products.stream().filter(p -> p.getId() == id).findFirst();
    }
}
