package com.uniquecollection.service;

import com.uniquecollection.model.CartItem;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;

/** In-memory shopping cart, one per client id (a random id the frontend keeps in localStorage). */
public class CartService {

    private final Map<String, List<CartItem>> carts = new ConcurrentHashMap<>();

    public List<CartItem> getCart(String clientId) {
        return carts.computeIfAbsent(clientId, k -> new CopyOnWriteArrayList<>());
    }

    public void addItem(String clientId, int productId, int quantity) {
        List<CartItem> cart = getCart(clientId);
        for (CartItem item : cart) {
            if (item.getProductId() == productId) {
                item.addQuantity(quantity);
                return;
            }
        }
        cart.add(new CartItem(productId, quantity));
    }

    public void removeItem(String clientId, int productId) {
        getCart(clientId).removeIf(item -> item.getProductId() == productId);
    }

    public void clear(String clientId) {
        getCart(clientId).clear();
    }
}
