package com.uniquecollection.handler;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.uniquecollection.model.CartItem;
import com.uniquecollection.model.Product;
import com.uniquecollection.service.CartService;
import com.uniquecollection.service.ProductService;
import com.uniquecollection.util.HttpUtil;
import com.uniquecollection.util.JsonUtil;

import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * /api/cart
 *   GET    -> current cart (items + total) for this client
 *   POST   body: {"productId": 1, "quantity": 1} -> add to cart
 *   DELETE query: ?productId=1 -> remove one product line from the cart
 */
public class CartHandler implements HttpHandler {

    private final CartService cartService;
    private final ProductService productService;

    public CartHandler(CartService cartService, ProductService productService) {
        this.cartService = cartService;
        this.productService = productService;
    }

    @Override
    public void handle(HttpExchange exchange) throws IOException {
        if (HttpUtil.handlePreflight(exchange)) return;

        String clientId = HttpUtil.clientId(exchange);
        String method = exchange.getRequestMethod();

        if ("GET".equalsIgnoreCase(method)) {
            sendCart(exchange, clientId);
            return;
        }

        if ("POST".equalsIgnoreCase(method)) {
            Map<String, String> body = JsonUtil.parseFlatObject(HttpUtil.readBody(exchange));
            int productId = parseIntOr(body.get("productId"), -1);
            int quantity = parseIntOr(body.get("quantity"), 1);
            if (productService.getById(productId).isPresent()) {
                cartService.addItem(clientId, productId, Math.max(1, quantity));
            }
            sendCart(exchange, clientId);
            return;
        }

        if ("DELETE".equalsIgnoreCase(method)) {
            String query = exchange.getRequestURI().getQuery();
            int productId = parseIntOr(queryParam(query, "productId"), -1);
            cartService.removeItem(clientId, productId);
            sendCart(exchange, clientId);
            return;
        }

        HttpUtil.sendJson(exchange, 405, "{\"error\":\"method not allowed\"}");
    }

    private void sendCart(HttpExchange exchange, String clientId) throws IOException {
        List<CartItem> items = cartService.getCart(clientId);
        List<String> jsonItems = new ArrayList<>();
        double total = 0;

        for (CartItem item : items) {
            Optional<Product> productOpt = productService.getById(item.getProductId());
            if (productOpt.isEmpty()) continue;
            Product p = productOpt.get();
            double lineTotal = p.getPrice() * item.getQuantity();
            total += lineTotal;

            Map<String, Object> fields = new LinkedHashMap<>();
            fields.put("productId", p.getId());
            fields.put("name", p.getName());
            fields.put("icon", p.getIcon());
            fields.put("price", p.getPrice());
            fields.put("quantity", item.getQuantity());
            fields.put("lineTotal", lineTotal);
            jsonItems.add(JsonUtil.toObject(fields));
        }

        String json = "{\"items\":" + JsonUtil.toArray(jsonItems) + ",\"total\":" + total + "}";
        HttpUtil.sendJson(exchange, 200, json);
    }

    private int parseIntOr(String value, int fallback) {
        try { return Integer.parseInt(value); } catch (Exception e) { return fallback; }
    }

    private String queryParam(String query, String key) {
        if (query == null) return null;
        for (String pair : query.split("&")) {
            String[] kv = pair.split("=", 2);
            if (kv.length == 2 && kv[0].equals(key)) return kv[1];
        }
        return null;
    }
}
