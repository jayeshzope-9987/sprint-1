package com.uniquecollection.handler;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.uniquecollection.service.UserService;
import com.uniquecollection.util.HttpUtil;
import com.uniquecollection.util.JsonUtil;

import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;

/** POST /api/login  body: {"username": "...", "password": "..."} */
public class LoginHandler implements HttpHandler {

    private final UserService userService;

    public LoginHandler(UserService userService) {
        this.userService = userService;
    }

    @Override
    public void handle(HttpExchange exchange) throws IOException {
        if (HttpUtil.handlePreflight(exchange)) return;

        if (!"POST".equalsIgnoreCase(exchange.getRequestMethod())) {
            HttpUtil.sendJson(exchange, 405, "{\"error\":\"method not allowed\"}");
            return;
        }

        Map<String, String> body = JsonUtil.parseFlatObject(HttpUtil.readBody(exchange));
        String username = body.getOrDefault("username", "");
        String password = body.getOrDefault("password", "");

        boolean ok = userService.login(username, password);

        Map<String, Object> result = new LinkedHashMap<>();
        result.put("success", ok);
        result.put("message", ok ? "Login successful" : "Invalid username or password");
        result.put("username", username);

        HttpUtil.sendJson(exchange, ok ? 200 : 401, JsonUtil.toObject(result));
    }
}
