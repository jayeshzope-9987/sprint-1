package com.uniquecollection.handler;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.uniquecollection.model.Product;
import com.uniquecollection.service.ProductService;
import com.uniquecollection.util.HttpUtil;
import com.uniquecollection.util.JsonUtil;

import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** GET /api/products -> full catalog as JSON */
public class ProductHandler implements HttpHandler {

    private final ProductService productService;

    public ProductHandler(ProductService productService) {
        this.productService = productService;
    }

    @Override
    public void handle(HttpExchange exchange) throws IOException {
        if (HttpUtil.handlePreflight(exchange)) return;

        if (!"GET".equalsIgnoreCase(exchange.getRequestMethod())) {
            HttpUtil.sendJson(exchange, 405, "{\"error\":\"method not allowed\"}");
            return;
        }

        List<String> jsonProducts = new ArrayList<>();
        for (Product p : productService.getAll()) {
            Map<String, Object> fields = new LinkedHashMap<>();
            fields.put("id", p.getId());
            fields.put("name", p.getName());
            fields.put("category", p.getCategory());
            fields.put("price", p.getPrice());
            fields.put("icon", p.getIcon());
            fields.put("stock", p.getStock());
            jsonProducts.add(JsonUtil.toObject(fields));
        }

        HttpUtil.sendJson(exchange, 200, JsonUtil.toArray(jsonProducts));
    }
}
