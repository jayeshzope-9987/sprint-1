package com.uniquecollection.handler;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.uniquecollection.service.UserService;
import com.uniquecollection.util.HttpUtil;
import com.uniquecollection.util.JsonUtil;

import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;

/** POST /api/register  body: {"username": "...", "password": "...", "email": "..."} */
public class RegisterHandler implements HttpHandler {

    private final UserService userService;

    public RegisterHandler(UserService userService) {
        this.userService = userService;
    }

    @Override
    public void handle(HttpExchange exchange) throws IOException {
        if (HttpUtil.handlePreflight(exchange)) return;

        if (!"POST".equalsIgnoreCase(exchange.getRequestMethod())) {
            HttpUtil.sendJson(exchange, 405, "{\"error\":\"method not allowed\"}");
            return;
        }

        Map<String, String> body = JsonUtil.parseFlatObject(HttpUtil.readBody(exchange));
        String username = body.getOrDefault("username", "");
        String password = body.getOrDefault("password", "");
        String email = body.getOrDefault("email", "");

        boolean ok = userService.register(username, password, email);

        Map<String, Object> result = new LinkedHashMap<>();
        result.put("success", ok);
        result.put("message", ok ? "Account created — you can log in now" : "Username already taken");

        HttpUtil.sendJson(exchange, ok ? 201 : 409, JsonUtil.toObject(result));
    }
}
