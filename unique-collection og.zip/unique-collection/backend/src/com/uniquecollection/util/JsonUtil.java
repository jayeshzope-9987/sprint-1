package com.uniquecollection.util;

import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Tiny hand-rolled JSON helper so the backend needs no external library.
 * It only supports what this project sends: flat objects (string/number/boolean
 * values) and lists of flat objects. Good enough for a learning project —
 * swap in a real library (Gson/Jackson) if you grow this further.
 */
public final class JsonUtil {

    private JsonUtil() {}

    public static String escape(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\").replace("\"", "\\\"");
    }

    /** Builds a JSON object string from an ordered map of key -> value (String, Number or Boolean). */
    public static String toObject(Map<String, Object> fields) {
        StringBuilder sb = new StringBuilder("{");
        boolean first = true;
        for (Map.Entry<String, Object> e : fields.entrySet()) {
            if (!first) sb.append(",");
            first = false;
            sb.append("\"").append(escape(e.getKey())).append("\":");
            sb.append(valueToJson(e.getValue()));
        }
        sb.append("}");
        return sb.toString();
    }

    private static String valueToJson(Object value) {
        if (value == null) return "null";
        if (value instanceof Number || value instanceof Boolean) return value.toString();
        return "\"" + escape(value.toString()) + "\"";
    }

    public static String toArray(List<String> jsonObjects) {
        return "[" + String.join(",", jsonObjects) + "]";
    }

    /**
     * Very small parser for a FLAT JSON object, e.g. {"username":"a","password":"b"}.
     * Returns a map of String -> String; numbers come back as their literal text.
     */
    public static Map<String, String> parseFlatObject(String json) {
        Map<String, String> result = new java.util.LinkedHashMap<>();
        if (json == null) return result;
        Pattern pair = Pattern.compile("\"([^\"]+)\"\\s*:\\s*(\"((?:[^\"\\\\]|\\\\.)*)\"|[0-9.\\-]+|true|false|null)");
        Matcher m = pair.matcher(json);
        while (m.find()) {
            String key = m.group(1);
            String raw = m.group(2);
            String val;
            if (raw.startsWith("\"")) {
                val = m.group(3).replace("\\\"", "\"").replace("\\\\", "\\");
            } else {
                val = raw;
            }
            result.put(key, val);
        }
        return result;
    }
}
