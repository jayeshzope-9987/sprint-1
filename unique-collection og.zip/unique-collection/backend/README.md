# Unique Collection — Backend

Plain Java backend, no Maven/Gradle/Spring needed — just a JDK (11+).
It uses `com.sun.net.httpserver.HttpServer`, which ships with every standard JDK.

## Run it from a terminal

```bash
cd backend
javac -d bin $(find src -name "*.java")
java -cp bin com.uniquecollection.Main
```

On Windows (PowerShell), replace the `javac` line with:

```powershell
javac -d bin (Get-ChildItem -Recurse -Filter *.java -Path src).FullName
```

You should see:

```
=======================================================
 Unique Collection backend running on http://localhost:8080
 Demo login -> username: demo   password: demo123
 ...
=======================================================
```

Leave this terminal running while you use the frontend.

## Run it from VS Code

1. Install the **Extension Pack for Java** (Microsoft) from the Extensions tab.
2. Open the `backend` folder in VS Code.
3. Open `src/com/uniquecollection/Main.java`.
4. Click **Run** above the `main` method (VS Code shows this automatically
   once the Java extension is installed), or press `F5`.

## Project layout

- `model/` — plain data classes (`Product`, `User`, `CartItem`)
- `service/` — in-memory "database" and logic (`ProductService`, `UserService`, `CartService`)
- `handler/` — one class per route, implementing `HttpHandler`
- `util/` — a tiny hand-rolled JSON encoder/decoder and shared HTTP/CORS helpers,
  used instead of an external JSON library so the project compiles with zero dependencies
- `Main.java` — starts the server and wires the routes together

## Extending it

- Swap `ProductService`'s in-memory list for a real database.
- Replace `JsonUtil` with Gson or Jackson once you're comfortable adding a build tool (Maven/Gradle).
- Hash passwords (e.g. with `jBCrypt`) instead of storing them as plain text.
- Add a real session/auth token instead of the current `X-Client-Id` header.
